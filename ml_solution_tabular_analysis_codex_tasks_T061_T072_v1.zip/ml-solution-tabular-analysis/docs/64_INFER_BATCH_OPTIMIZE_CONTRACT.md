# 推論（infer） batch / optimize 契約 v1（controllerは使わない）

## ゴール
- infer.mode=single : 単独タスク
- infer.mode=batch : サマリータスク + 条件ごとの child 推論タスク（single相当）
- infer.mode=optimize : サマリータスク + trialごとの child 推論タスク（single相当、Optunaで探索）

## 制約
- 推論は PipelineController を使わない（ユーザー要求）。
- ただし ClearML Task を clone/enqueue して child task を作ることは許容（実装簡潔のため）。

## UI 出力
- child task: 各条件の入力→出力テーブルを PLOTS に出す（Plotly Table）
- summary task:
  - batch: 全条件のテーブル + 予測分布など
  - optimize: Optuna可視化（history/parallel coords/importance/response surface） + 上位条件テーブル

## HyperParameters
- summary: Inputs/Optimize などをカテゴリ別に
- child: Inputs/Model/Dataset を最小で
