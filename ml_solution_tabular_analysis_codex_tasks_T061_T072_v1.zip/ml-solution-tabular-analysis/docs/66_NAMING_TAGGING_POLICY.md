# タスク名・タグ・Properties ポリシー v1（増えすぎ防止）

## 目的
ClearML上でタスク/データセットが増えても「探せる」こと。

## タスク名（例）
- dataset_register: `dataset_register__{dataset_id_hint}`
- preprocess: `preprocess__{preprocess_variant}__ds={raw_id_short}`
- train_model: `train__{model_abbr}__pp={preprocess_variant}__ds={raw_id_short}`
- leaderboard: `leaderboard__pp={preprocess_variant}__models={N}__ds={raw_id_short}`
- infer(single): `infer__single__model={model_abbr}`
- infer(batch summary): `infer__batch__n={N}__model={model_abbr}`
- infer(optimize summary): `infer__optimize__trials={N}__model={model_abbr}`

## タグ（最小）
- 共通: `usecase:<usecase_id>`, `process:<name>`, `schema:<v>`
- dataset: `dataset:<raw_dataset_id>`
- preprocess: `preprocess:<variant>`
- model: `model:<abbr>`
- run group: `grid_run:<id>`（必要時）

## Properties（検索キー最小）
- dataset_register: `raw_dataset_id`
- preprocess: `processed_dataset_id`, `split_hash`, `schema_hash`
- train: `model_id`, `best_score`, `primary_metric`, `processed_dataset_id`
- leaderboard: `recommended_model_id`, `recommended_train_task_id`, `selection_policy`
- infer: `model_id`, `infer_mode`, `input_source`, `provenance_train_task_id` 等（最小）

## ルール
- 文字列は短く。長い詳細は artifact（report json/csv）へ。
- タグは key:value のみ。増やしすぎない（10個程度まで）。
