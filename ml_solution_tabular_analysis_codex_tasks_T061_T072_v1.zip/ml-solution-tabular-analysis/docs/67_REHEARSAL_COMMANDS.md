# 試験（ローカル→社内）リハーサルコマンド v1

## 1) dataset_register（ローカル）
```bash
python -m tabular_analysis.cli task=dataset_register run.clearml.enabled=true run.clearml.execution=logging \
  data.dataset_path=/tmp/ta_rehearsal_data/toy_reg.csv data.target_column=target
```

## 2) pipeline（agent / PipelineController）
```bash
# agent起動: clearml-agent daemon --foreground --queue default --create-queue
python -m tabular_analysis.cli task=pipeline/train_regression \
  run.clearml.enabled=true run.clearml.execution=pipeline_controller run.clearml.queue_name=default \
  data.raw_dataset_id=<RAW_DATASET_ID> pipeline.preprocess_variant=stdscaler_ohe pipeline.model_set=regression_all
```

## 3) ローカル一括（agent不要、ただしClearML tasksは個別に作る）
```bash
python -m tabular_analysis.ops.local_orchestrator train_regression \
  --dataset-path /tmp/ta_rehearsal_data/toy_reg.csv --target-column target \
  --preprocess stdscaler_ohe --model-set regression_all --clearml --project-root LOCAL
```

## 4) infer single/batch/optimize
```bash
python -m tabular_analysis.cli task=infer infer.mode=single infer.model_id=<MODEL_ID> infer.input_path=/tmp/infer.csv

python -m tabular_analysis.cli task=infer infer.mode=batch infer.model_id=<MODEL_ID> infer.batch.inputs_path=/tmp/batch_inputs.csv

python -m tabular_analysis.cli task=infer infer.mode=optimize infer.model_id=<MODEL_ID> infer.optimize.n_trials=30
```
