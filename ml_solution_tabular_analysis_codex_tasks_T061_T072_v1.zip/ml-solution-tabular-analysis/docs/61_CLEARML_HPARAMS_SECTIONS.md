# ClearML HyperParameters 分類（セクション） 契約 v1

## ゴール
ClearML UI の Configuration > Hyperparameters が **GENERAL一択**にならないよう、セクションを分ける。

## 方針
- `Task.connect(params_dict, name="<Section>")` を使用してセクションを作る。
- 全設定を入れない（ノイズ回避）。再実行・比較に必要な最小キーのみ。
- 具体的な抽出は `src/tabular_analysis/clearml/hparams.py` に集約。

## セクション（推奨）
- `Inputs` : 入力データに関するもの（dataset_id/path, target_column, infer入力など）
- `Dataset` : dataset_id, processed_dataset_id, schema_hash, split_hash 等
- `Preprocess` : preprocess variant, split設定, store_features 等
- `Model` : model variant, 主要パラメータ（上位10件まで等）
- `Eval` : metrics一覧, primary_metric, cv設定
- `Optimize` : optimize探索空間, sampler, n_trials, objective
- `Execution` : clearml.execution, project_root, queue, code_version
- `Links` : upstream_task_id, train_task_ids, recommended_model_id 等（最小）

## 各タスクの必須キー例
### dataset_register
- Inputs: dataset_path, target_column
- Dataset: raw_dataset_id

### preprocess
- Dataset: raw_dataset_id, processed_dataset_id(結果)
- Preprocess: variant, split.seed/strategy
- Eval: task_type

### train_model
- Dataset: processed_dataset_id, schema_hash, split_hash
- Model: variant, seed, 주요params
- Eval: metrics, primary_metric

### leaderboard
- Links: train_task_ids（数が多い場合は artifact に寄せる）, selection_policy
- Eval: metrics, scoring weights（multi-metric）

### infer
- Inputs: infer.mode, infer.input_path or infer.input_json
- Model: model_id
- Dataset: training dataset/provenance（読み取り）
- Optimize: 探索空間など（optimize時）
