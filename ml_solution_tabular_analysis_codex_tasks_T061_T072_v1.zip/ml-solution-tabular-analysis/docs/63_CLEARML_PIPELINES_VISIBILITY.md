# ClearML の PIPELINES タブに表示させるための要点 v1

## 目的
- train pipeline を ClearML UI の左タブ「PIPELINES」に表示し、子タスク階層と依存関係を追えるようにする。

## 重要ポイント（実装側）
- PipelineController が作成する controller task が `TaskTypes.controller` で作られていること（または ClearML が pipeline として扱う作法に沿うこと）
- `controller.start()`（agent実行）または、少なくとも「controller task を ClearML に登録してから」ステップを queue に投入すること
- project を pipeline専用（例: `.../99_pipeline`）に統一し、探索しやすくする
- template task の tags が揃っており、clone元が見つかること（T058/T059運用）

## 検証手順（運用）
1) template を作成/validate（manage_clearml_templates）
2) agent を起動（queue名を合わせる）
3) `run.clearml.execution=pipeline_controller` で pipeline を実行
4) ClearML UI: PIPELINES タブに pipeline が出るか確認
