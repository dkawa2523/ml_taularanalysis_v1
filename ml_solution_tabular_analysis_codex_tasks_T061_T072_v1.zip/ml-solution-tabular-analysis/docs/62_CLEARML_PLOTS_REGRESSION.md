# ClearML PLOTS/SCALARS 可視化 契約（回帰中心） v1

## 共通指標（Scalars）
- `metrics/r2`
- `metrics/mse`
- `metrics/rmse`
- `metrics/mae`

## dataset_register / preprocess（PLOTS）
- データ概要テーブル（head、列型、欠損率など）: Plotly Table
- 目的変数分布（回帰: histogram）: Plotly
- 数値特徴の分布（上位K列）: Plotly
- 欠損率（bar）: Plotly

## train_model（PLOTS）
- 指標テーブル（R2/MSE/RMSE/MAE）: Plotly Table
- y_true vs y_pred 散布図 + y=x ライン（R2表示）: Plotly
- residual plot（任意）: Plotly
- feature importance（取得できるモデルのみ）: Plotly bar
- CV が有効な場合: fold別スコアのbox/violin（任意）

## leaderboard（PLOTS）
- モデル×指標のテーブル（並び替え/ハイライト）: Plotly Table
- 総合スコア上位Kのbar: Plotly
- パレート散布図（例: R2 vs RMSE）: Plotly（任意）

## infer（PLOTS）
- **入力→出力のテーブル**（single/batch/optimize 共通）: Plotly Table
- batch: 予測値分布（hist）+ 上位/下位のサンプルテーブル（任意）
- optimize: Optunaグラフ（history, parallel coords, importance, response surface）
