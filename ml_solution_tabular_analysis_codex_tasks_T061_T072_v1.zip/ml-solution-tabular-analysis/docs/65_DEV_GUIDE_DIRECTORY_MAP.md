# 開発者ガイド：どこを見て直すか v1

## 目的
開発者が目的別に「見るべきディレクトリ/ファイル」を即座に特定できるようにする。

## 1) モデル追加・改良
- `src/tabular_analysis/registry/models/`（モデル登録・factory）
- `conf/group/model/`（モデルvariant YAML）

## 2) 前処理追加・改良
- `src/tabular_analysis/registry/preprocess/`（前処理登録・bundle）
- `conf/group/preprocess/`

## 3) 評価指標・比較ロジック
- `src/tabular_analysis/metrics/`（R2/MSE/RMSE/MAE 等）
- `src/tabular_analysis/processes/leaderboard.py`（集計・推薦）
- `conf/leaderboard/`（重み/方針）

## 4) ClearML統合（名前/タグ/Properties/HyperParams/Artifacts）
- `src/tabular_analysis/clearml/`（ここだけ読めばよい）
  - `hparams.py`：カテゴリ別 HyperParameters
  - `ui_logger.py`：PLOTS/SCALARS出力
  - `naming.py`：タスク名・タグ

## 5) 可視化（Plotly）
- `src/tabular_analysis/viz/`（Plotly Figure を生成）
  - `data_profile.py`
  - `regression_plots.py`
  - `leaderboard_plots.py`
  - `optuna_plots.py`

## 6) pipeline / orchestrator
- `src/tabular_analysis/processes/pipeline.py`（PipelineController）
- `src/tabular_analysis/ops/local_orchestrator.py`（ローカル一括）
