# APPLY: T061〜T072（update-3_clearml 向け）

このZIPは **Codex CLI による自動実装指示ファイル群**です。コード本体は含みません（Codexが実装します）。

## 1) 追加方法（上書き追加）
ワークスペース直下で unzip してください（ZIP内に `ml-solution-tabular-analysis/` が含まれます）。

```bash
cd <workspace>
unzip -o ml_solution_tabular_analysis_codex_tasks_T061_T072_v1.zip -d .
```

## 2) queue.json に追記
既存の queue に追加タスクをマージします。

```bash
cd <workspace>/ml-solution-tabular-analysis
python tools/codex_loop/merge_queue_additions.py --queue work/queue.json --add work/queue_additions_T061_T072.json
```

## 3) 実行（推奨: 1タスクずつ）
```bash
python tools/codex_loop/run.py --repo . --status
python tools/codex_loop/run.py --repo . --once
```

連続実行:
```bash
python tools/codex_loop/run.py --repo .
```

## 4) 実装後の確認
- docs/67 のコマンドで dataset_register → pipeline → infer を試験
- ClearML UIで以下を確認:
  - PIPELINES タブに pipeline が出る（T063）
  - HyperParameters がセクション分割される（T064）
  - dataset_register/preprocess/train/leaderboard/infer の PLOTS にPlotly図が出る（T065〜T070）
  - タスク名・タグでモデル/前処理/データセットが判別できる（T066, T066）

## 重要（冗長化防止）
- ClearML統合は `src/tabular_analysis/clearml/` に集約する
- 可視化は `src/tabular_analysis/viz/` に集約する
- HyperParameters は最小キーのみ（docs/61）
